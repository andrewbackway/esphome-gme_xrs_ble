#include "xrs_select.h"
#include "../xrs_radio.h"
#include "esphome/core/log.h"

namespace esphome {
namespace gme_xrs_radio {

static const char *const TAG = "gme_xrs_radio.select";

void XRSRadioSelect::update_options_() {
  if (this->parent_ == nullptr)
    return;

  std::vector<std::string> opts;

  switch (this->type_) {
    case XRS_SELECT_ZONE: {
      opts = this->parent_->get_zone_options();
      // If we don't yet have a channel table, at least expose the current zone
      if (opts.empty()) {
        char buf[8];
        std::snprintf(buf, sizeof(buf), "Z%u",
                      static_cast<unsigned>(this->parent_->get_current_zone()));
        opts.emplace_back(buf);
      }
      break;
    }

    case XRS_SELECT_CHANNEL: {
      opts = this->parent_->get_channel_options();
      // Same fallback: current zone/channel only
      if (opts.empty()) {
        char buf[32];
        std::snprintf(buf, sizeof(buf), "Z%u / Ch %u",
                      static_cast<unsigned>(this->parent_->get_current_zone()),
                      static_cast<unsigned>(this->parent_->get_current_channel()));
        opts.emplace_back(buf);
      }
      break;
    }

    default:
      break;
  }

  this->options_.assign(opts.begin(), opts.end());

  // CRITICAL: teach the base class what options are valid
  this->traits.set_options(this->options_);
}

void XRSRadioSelect::refresh_from_parent() {
  if (this->parent_ == nullptr)
    return;

  // Rebuild options from the channel table / current state
  this->update_options_();

  char buf[32] = {0};

  switch (this->type_) {
    case XRS_SELECT_ZONE: {
      unsigned zone = this->parent_->get_current_zone();
      std::snprintf(buf, sizeof(buf), "Z%u", zone);
      this->publish_state(buf);
      break;
    }

    case XRS_SELECT_CHANNEL: {
      unsigned zone = this->parent_->get_current_zone();
      unsigned ch = this->parent_->get_current_channel();
      std::snprintf(buf, sizeof(buf), "Z%u / Ch %u", zone, ch);
      this->publish_state(buf);
      break;
    }

    default:
      break;
  }
}

void XRSRadioSelect::control(const std::string &value) {
  if (this->parent_ == nullptr)
    return;

  // Value is already validated against traits/options by the base class

  if (this->type_ == XRS_SELECT_ZONE) {
    // Value looks like "Z1", "Z2", ...
    unsigned zone = 0;
    if (std::sscanf(value.c_str(), "Z%u", &zone) == 1) {
      this->parent_->set_zone(static_cast<uint8_t>(zone));
      this->publish_state(value);
    } else {
      ESP_LOGW(TAG, "Zone select: could not parse '%s'", value.c_str());
    }

  } else if (this->type_ == XRS_SELECT_CHANNEL) {
    // Value looks like "Z1 / Ch 46"
    unsigned zone = 0;
    unsigned ch = 0;
    if (std::sscanf(value.c_str(), "Z%u / Ch %u", &zone, &ch) == 2) {
      this->parent_->set_channel(static_cast<uint8_t>(zone),
                                 static_cast<uint8_t>(ch));
      this->publish_state(value);
    } else {
      ESP_LOGW(TAG, "Channel select: could not parse '%s'", value.c_str());
    }
  }
}

}  // namespace gme_xrs_radio
}  // namespace esphome
